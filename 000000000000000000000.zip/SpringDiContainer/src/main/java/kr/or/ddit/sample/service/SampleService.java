package kr.or.ddit.sample.service;

public interface SampleService {
	public StringBuffer retrieveInformation(String pk);
	
}
