package kr.or.ddit.hierarchy;

import java.util.Map;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.or.ddit.sample.service.SampleService;

public class ContextHierachyTextView {
	public static void main(String[] args) {
		
		ConfigurableApplicationContext parent = new ClassPathXmlApplicationContext("kr/or/ddit/sample/conf/Parent-Context.xml");
		ConfigurableApplicationContext child = new ClassPathXmlApplicationContext(
													new String[] {"kr/or/ddit/sample/conf/Sample-context.xml"}
													, parent
												);
		child.registerShutdownHook();
		parent.registerShutdownHook();
		
		SampleService service = child.getBean(SampleService.class);
		System.out.println(service.retrieveInformation("PK_2"));
		
		Map<String, String>  oracleDB = (Map) child.getBean("oracleDB");
		System.out.println(oracleDB);
		//자식을 통해서 부모의 자원에 접근하는거 가능 
		
		SampleService service2 = parent.getBean(SampleService.class);
		//부모를 통해서 자식의 자원에 접근하는거 불가능
	}
}
