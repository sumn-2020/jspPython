package kr.or.ddit.memo.dao;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Repository;

import kr.or.ddit.vo.MemoVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
//FileSystemMemoDAOImpl를 사용하기 위해서는 빈 등록 해야됨 Memo-Context.xml
public class FileSystemMemoDAOImpl implements MemoDAO {
	
	//주입하기
	@Inject
	private ApplicationContext context;

	
	//context에 모든 주입 끝난 후 실행 
	//private File dataBase = new File("d:/memos.dat"); 이 코드 대신 해줌 
	@PostConstruct //생성하고 모든 주입이 끝난 뒤에 실행 
	public void init() {
		dataBase =   context.getResource("file:d:/memos.dat");
		log.info("리소스 로딩: {} ", dataBase);
		try(
				//FileInputStream fis = new FileInputStream(dataBase);	
				InputStream fis =  dataBase.getInputStream();
				
				BufferedInputStream bis = new BufferedInputStream(fis); //속도 높이기 위해서 사용
				ObjectInputStream ois = new ObjectInputStream(bis);
			){
	            memoTable = (Map<Integer, MemoVO>) ois.readObject(); //ois.readObject()이걸 읽어와서 memoTable에 넣어주기 
			}catch(Exception e) {
				System.err.println(e.getMessage()); //에러로그 출력
				this.memoTable = new HashMap<Integer, MemoVO>();
		}
	}
	
	private Resource dataBase;
	private Map<Integer, MemoVO> memoTable;
	
	//싱글톤 - 생성자가 private 일 경우 싱글톤을 이용해서 접근할 수 있음 
	/*private static FileSystemMemoDAOImpl instance; 
	public static FileSystemMemoDAOImpl getInstance() {
		if(instance==null)
			instance = new FileSystemMemoDAOImpl();
		return instance;
	}*/
	
	
	
	//생성자
/*	private FileSystemMemoDAOImpl() { 
		//뒷단에 들어있는 데이터들을 (역직렬화해서  SerializationTest참고) 받아오기  -  이 예제에서는 db없기 떄문에 임의적으로 만들어서 불러옴
		try(
				//FileInputStream fis = new FileInputStream(dataBase);	
				InputStream fis =  dataBase.getInputStream();
				
				BufferedInputStream bis = new BufferedInputStream(fis); //속도 높이기 위해서 사용
				ObjectInputStream ois = new ObjectInputStream(bis);
			){
	            memoTable = (Map<Integer, MemoVO>) ois.readObject(); //ois.readObject()이걸 읽어와서 memoTable에 넣어주기 
			}catch(Exception e) {
				System.err.println(e.getMessage()); //에러로그 출력
				this.memoTable = new HashMap<Integer, MemoVO>();
		}
	}*/
	
	
	
	
	@Override
	public List<MemoVO> selectMemoList() {
		return new ArrayList<>(memoTable.values()); //memoTable값들을 ArrayList형태로 반환 
	}

	@Override
	public int insertMemo(MemoVO memo) {
		//1. memo.getCode()만들기 
		int maxCode = memoTable.keySet().stream()
						  				.mapToInt(key->key.intValue()) //int형으로 변경하기 
						  				.max()
						  				.orElse(0); //max값이 있으면 mnax값 반환하고 없으면 0반환
		memo.setCode(maxCode+1); //insert하기 전에 primary key를 생성하는 코드 만들어 줌 

		
		//2. memo.getCode()에 맞춰서 memo값 넣어주기 
		memoTable.put(memo.getCode(),memo); 
		serializeMemoTable();
		return 1;
	}
	
	//파일시스템(가짜 DB)에 정보가 반영되는 로직
	//누군가가 글을 쓸때마다 쓴 글을 모아서 memoTable에 써놔야됨 (=>직렬화해서 insertMemo에 출력시킴)
	private void serializeMemoTable() {
		try(
			FileOutputStream fos = new FileOutputStream(dataBase.getFile());	
			ObjectOutputStream oos = new ObjectOutputStream(fos);
		){
			oos.writeObject(memoTable);
		}catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public int updateMemo(MemoVO memo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMemo(int code) {

	
		
		return 0;
	}

	

}
