package kr.or.ddit.memo.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import kr.or.ddit.memo.MemoTestView;
import kr.or.ddit.memo.dao.FileSystemMemoDAOImpl;
import kr.or.ddit.memo.dao.MemoDAO;
import kr.or.ddit.memo.service.MemoService;


@ComponentScan("kr.or.ddit.memo")
@Lazy
public class MemoContextConfiguration {

/*	@Bean //dao 하나를 bean으로 등록했음 
	@Scope("prototype") //inject될때마다  프로토타입으로 주입됨
	public MemoDAO memoDAO() {
		return new FileSystemMemoDAOImpl();
	}
	
	@Bean
	public MemoService generateService(MemoDAO dao) { //위에 memoDAO를 알아서 dao에 알아서 주입받아서 작섭함
		return new MemoService(dao);
	}
	
	@Bean("testView")
	public MemoTestView testView(MemoService service) {
		MemoTestView view = new MemoTestView();
		view.setService(service);
		1return view;
	}
*/
	
	
}











