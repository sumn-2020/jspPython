package kr.or.ddit.web;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class HelloServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) 
						throws IOException, ServletException 
	{
		
		PrintWriter out =  resp.getWriter();
		out.println("Hello servlet");
		out.close();
		
		
	}
	

}