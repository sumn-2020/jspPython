package kr.or.ddit.web;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
//import java.time.format.DatetimeFormatter;


//localhost/hello/now -> current server time : dasdfasdf



public class NowServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) 
						throws IOException, ServletException 
	{
		//MIME text
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out =  resp.getWriter();
		//LocalTime time = LocalTime.now();
		Date now = new Date();
		String message = String.format("current server time: %tc", now);
		out.println(message);
		out.close();
		
		
	}
	

}