package kr.or.ddit.web;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;


import java.util.*;


//클라이언트가 접근할 수 없는 폴더에 있는 이미지를 서비스 하기 위해 매개역할을 하는 클래스 
public class ImageStreamingServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) 
						throws IOException, ServletException 
	{
		
		
		//응답데이터에 이미지 컨텐츠를 포함시키기 위해 
		resp.setContentType("image/jpeg"); //D:\B_Util\5_5.Tomcat\apache-tomcat-8.5.84\conf\web.xml에 있음
		String imageFolder = "d:/contents/images";
		String imageName = "cat1.jpg";

		File imageFile = new File(imageFolder,imageName);
		
		FileInputStream fis = new FileInputStream(imageFile);
		OutputStream os = resp.getOutputStream();
		
		//이미지 끝날 때까지 반복
		int tmp = -1;
		while((tmp = fis.read()) != -1){
			os.write(tmp);
		}
		
		fis.close();
		os.close();
		

		
		
	}

}