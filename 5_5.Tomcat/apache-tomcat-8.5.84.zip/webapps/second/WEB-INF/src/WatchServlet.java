package kr.or.ddit.web;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;


import java.util.*;


public class WatchServlet extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse resp) 
						throws IOException, ServletException 
	{
		
		
		//응답데이터에 한글 컨텐츠를 포함시키기 위해 
		resp.setContentType("text/html;charset=UTF-8");
		
		StringBuffer content = new StringBuffer();
		//Date now = new Date();
		
		content.append("<html>\n");
		content.append("<body>\n");
		content.append(String.format("<h4>current context path : %s</h4>\n", req.getContextPath()));
		content.append(String.format("<h4>last received server time : %tc</h4>\n", new Date()));
		content.append(String.format("<h4>current client time: <span id='timeArea'></span>\n"));
		
		
		content.append("<script>\n");
		content.append("setInterval(function(){");
		content.append("let now = new Date();\n");
		content.append("let timeArea = document.getElementById('timeArea');\n");
		content.append("timeArea.innerHTML = now;\n");		
		content.append("}, 1000)");
		
		
		content.append("</script>\n");
		content.append("</body>\n");
		content.append("</html>\n");
		
		
		
		PrintWriter out =  resp.getWriter();
		out.println(content);
		out.close();

		
		
	}

}