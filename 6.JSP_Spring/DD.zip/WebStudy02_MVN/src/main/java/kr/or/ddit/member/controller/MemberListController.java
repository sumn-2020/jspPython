package kr.or.ddit.member.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.member.service.MemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.mvc.AbstractController;
import kr.or.ddit.mvc.view.InternalResourceViewResolver;
import kr.or.ddit.vo.DataBasePropertyVO;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.SearchVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MemberListController implements AbstractController {
	
	private MemberService service = new MemberServiceImpl();
	
	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//req.setCharacterEncoding("UTF-8"); front에 있기 때문에 필요없ㅇ
		
		//검색 필터링 - 파라미터 받기 
		String searchType = req.getParameter("searchType");
		String searchWord = req.getParameter("searchWord");
		
		SearchVO simpleConition = new SearchVO(searchType, searchWord); //검색 

		
		//페이징
		String pageParam = req.getParameter("page"); //넘어오는 page값이 숫자가 아니라 string 임  이때 아래에서 파싱해야됨 
		int currentPage = 1;
		if(StringUtils.isNumeric(pageParam)) { //이 if문에 들어왔다면 넘어온 파라미터 값이 숫자니까 파싱
			currentPage = Integer.parseInt(pageParam);
			
		}
		
		PagingVO<MemberVO> pagingVO = new PagingVO<>(4,2);  //4개와 2개 페이지만 보여줌 
		//PagingVO<MemberVO> pagingVO = new PagingVO<>(); 
		//pagingVO.setCurrentPage(1); //1페이지 요청    pagingVO에서 setter호출 setCurrentPage
		pagingVO.setCurrentPage(currentPage); 
		pagingVO.setSimpleCondition(simpleConition); //검색 
		
		
		//1.  요청분석
		//String memId = req.getParameter("memId"); 
		//String memName = req.getParameter("memName"); 
		//String memMail = req.getParameter("memMail"); 
		//String memHp = req.getParameter("memHp"); 
		//String memAdd1 = req.getParameter("memAdd1"); 
		//String memAdd2 = req.getParameter("memAdd2"); 
		//String memMileage = req.getParameter("memMileage"); 
		
		//2 모델확보 - 모델레이어 사용(service 가져와서 사용)
		List<MemberVO> memberList = service.retrieveMemberList(pagingVO); 
		req.setAttribute("pagingVO", pagingVO); //페이징
		
		//3 
		req.setAttribute("memberList", memberList); //memberList 가져와서 "memberList"라는 이름으로 jsp에 보내주기 
		
		
		
		
		log.info("paging data : {}", pagingVO);
		
		
		//4.
		String viewName = "member/memberList";
		
		return viewName;
		
		//5번단계 
		//new InternalResourceViewResolver("/WEB-INF/views/", ".jsp").resolveView(viewName, req, resp);
		
		
		
		
	}
}
