package kr.or.ddit.designpattern.adapterpattern;

public class Adaptee {
	public  void  specificRequest() {
		System.out.println("Adaptee가 명령에 대한 처리를 수행했음");
	}
}
