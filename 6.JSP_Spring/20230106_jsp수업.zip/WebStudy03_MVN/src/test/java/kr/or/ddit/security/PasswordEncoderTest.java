package kr.or.ddit.security;

import org.junit.Test;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PasswordEncoderTest {

	   PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
	   
	   String password = "java";
	   String mem_pass = "{bcrypt}$2a$10$re9EACGK9.Fr9i5yNva7SOolzwdyXmj2yYaQXGCuRH6SbqucHqIna"; 

	   public void encodeTest() {
	      String encoded = encoder.encode(password);
	      log.info("mem_pass: {}", encoded);
	   }
	   
	   @Test
	   public void matchTest() {
		  log.info("match result : {}",  encoder.matches(password, mem_pass)); //true 가 나오면 로그인 성공 
	   }
	   
	   
}









