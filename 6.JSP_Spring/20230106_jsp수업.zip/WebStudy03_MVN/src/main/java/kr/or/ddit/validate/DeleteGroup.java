package kr.or.ddit.validate;

public interface DeleteGroup { //회원탈퇴할때는 아이디,비번만 이씅면 되니까 굳이 default상속받을픽ㄹ요벗음 

}
