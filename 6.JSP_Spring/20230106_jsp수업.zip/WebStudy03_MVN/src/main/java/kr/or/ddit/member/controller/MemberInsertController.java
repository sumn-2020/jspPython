package kr.or.ddit.member.controller;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.MemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.mvc.annotation.RequestMethod;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestPart;
import kr.or.ddit.mvc.annotation.stereotype.Controller;
import kr.or.ddit.mvc.annotation.stereotype.RequestMapping;
import kr.or.ddit.mvc.multipart.MultipartFile;
import kr.or.ddit.mvc.multipart.MultipartHttpServletRequest;
import kr.or.ddit.mvc.view.InternalResourceViewResolver;
import kr.or.ddit.validate.InsertGroup;
import kr.or.ddit.validate.ValidationUtils;
import kr.or.ddit.vo.MemberVO;

/**
 * backend controller(= command handler) -> POJO(Plain Old Java Object)
 */


@Controller
public class MemberInsertController {
	
	private MemberService service = new MemberServiceImpl();
	
	
/*	//프론트 컨트롤러 호출
	public String process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String method = req.getMethod();
		
		RequestMethod requestMethod = RequestMethod.valueOf(method.toUpperCase()); 
		String viewName = null;
		if(requestMethod==RequestMethod.GET) { //requestMethod가  RequestMethod의 GET이면
			viewName = memberForm(req, resp);
		}else if(requestMethod==RequestMethod.POST) { //requestMethod가  RequestMethod의 post면
			viewName = memberInsert(req, resp);
		}else {
			 resp.sendError(405, method+"는 지원하지 않음.");
		}
		return viewName;
	}*/
	
	@RequestMapping("/member/memberInsert.do")
	public String memberForm() {
		return "member/memberForm";
	}
/*	public String memberForm(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		return "member/memberForm";
	}*/
	
	@RequestMapping(value="/member/memberInsert.do", method=RequestMethod.POST) //이 url로 받은 요청중에서 post만 받을 수 있다 
	public String memberInsert(
			
			HttpServletRequest req
			,@ModelAttribute("member") MemberVO member 
			,@RequestPart(value="memImage", required=false) MultipartFile memImage
			
	) throws ServletException, IOException {
		
		
		//insert할때 회원 프로필 첨부하기
		//client에게 memImages로 가져와서
		member.setMemImage(memImage);
		/*if(req instanceof MultipartHttpServletRequest) {
			MultipartFile memImage = ((MultipartHttpServletRequest) req).getFile("memImage"); //클라이언트로부터 memImage를 받아와서 
			member.setMemImage(memImage);
			if(memImage != null && !memImage.isEmpty()) {
			member.setMemImg(memImage.getBytes());
			}
		
		}*/
	
		
		
		
		
		
		
		
		

/*		ModelAttributeMethodProccessor으로 넘어감
 * 	 	MemberVO member = new MemberVO(); 
		req.setAttribute("member", member); 
		 Map<String, String[]> parameterMap =  req.getParameterMap();
		try {
			BeanUtils.populate(member, parameterMap);
				
		}catch(IllegalAccessException | InvocationTargetException e) {
			throw new ServletException(e);
		}
*/
		
	
	
		Map<String, List<String>> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors); 
		boolean valid = ValidationUtils.validate(member, errors, InsertGroup.class);
		String viewName = null;
		
		if(valid) {
			ServiceResult result =  service.createMember(member);
			switch (result) {
			case PKDUPLICATED: 
				req.setAttribute("message", "아이디 중복");
				viewName = "member/memberForm";
				break;  
			case FAIL: 
				req.setAttribute("message", "서버에 문제 있음. 조금있다하시오");
				viewName = "member/memberForm";
				break;
			default:
				viewName = "redirect:/"; 
				break;
			}
		}else {
			viewName = "member/memberForm";
		}
		
		return viewName;

	}
	
}
