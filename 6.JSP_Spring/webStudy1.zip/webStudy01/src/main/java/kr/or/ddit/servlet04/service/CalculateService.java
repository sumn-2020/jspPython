package kr.or.ddit.servlet04.service;

import java.util.Properties;

public interface CalculateService {
	
//	public Properties retrieveData();
	
	public int plus(int a, int b);
	public int minus(int a, int b);
	public int multiply(int a, int b);
	public int divice(int a, int b);
	
	
}


