package kr.or.ddit.prod.controller;

import javax.servlet.annotation.WebServlet;

@WebServlet("/prod/prodList.do")
public class ProdListControllerServlet {

}
