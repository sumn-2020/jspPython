package kr.or.ddit.prod.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import kr.or.ddit.vo.ProdVO;
import lombok.extern.slf4j.Slf4j;


@Slf4j //log 프레임워크 따로 안깔아도 이거만 써도 끝
public class ProdDAOImplTest {

	private ProdDAO dao = new ProdDAOImpl();
	
	@Test
	public void testSelectProd() {
		ProdVO prod = dao.selectProd("P101000001");
		assertNotNull(prod); //null이 있는지 확인
		log.info("buyer : {}", prod.getBuyer());
		prod.getMemberSet().stream()
						   .forEach(user->{ //사용자 한명한명에 접근
							  log.info("구매자:{}", user);
						   });
	
	
	}

}
