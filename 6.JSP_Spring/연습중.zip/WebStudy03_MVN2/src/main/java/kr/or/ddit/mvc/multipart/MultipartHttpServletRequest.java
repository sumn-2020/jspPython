package kr.or.ddit.mvc.multipart;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


/**
 * Part를 -> MultipartFile로 만들기
 *
 */

//요청정보(Part)는 직접 수정할 수 없어서 중간에서 MultipartFile 만들어줌 
public class MultipartHttpServletRequest extends HttpServletRequestWrapper{

	
	private Map<String, List<MultipartFile>> fileMap; //모든 파일 정보는 얘가 가지고있음 . 얘한테 접근할라면 key(=>name)를 통해서 접근
	
	
	public MultipartHttpServletRequest(HttpServletRequest request) throws IOException, ServletException {
		super(request);
		parseRequest(request);
	}

	private void parseRequest(HttpServletRequest request) throws IOException, ServletException {

		
		fileMap = new LinkedHashMap<>();
		request.getParts().stream()
			              .filter((p)->p.getContentType()!=null) //일반 문자는 싹 걸러냄
			              .forEach((p)->{
			            	  String partName = p.getName();
			            	  MultipartFile file = new StandardServletMultipartFile(p);
			            	  List<MultipartFile> fileList =  Optional.ofNullable(fileMap.get(partName))
			            			  								.orElse(new ArrayList<>());
			            	  fileList.add(file);
			            	  fileMap.put(partName, fileList);
			            	  
			              });
		
	}

	public Map<String, List<MultipartFile>> getFileMap() {
		return fileMap;
	}

	public MultipartFile getFile(String name) {
		List<MultipartFile> files = fileMap.get(name);
		if(files != null && !files.isEmpty() ) { //비어있지 않다면 
			return files.get(0); //이 안에서 하나만 꺼내기 
		}else { //없으면 ?
			return null;
		}
	}
	
	
	public List<MultipartFile> getFiles(String name) {
		return fileMap.get(name);
	}
	
	

	public Enumeration<String> getFileName(){
		Iterator<String> names = fileMap.keySet().iterator();
		return new Enumeration<String>() {

			@Override
			public boolean hasMoreElements() {
				return names.hasNext();
			}

			@Override
			public String nextElement() {
				return names.next();
			}
			
		};
	}
	

}
