package kr.or.ddit.prod.controller;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.mvc.annotation.RequestMethod;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.annotation.resolvers.RequestPart;
import kr.or.ddit.mvc.annotation.stereotype.Controller;
import kr.or.ddit.mvc.annotation.stereotype.RequestMapping;
import kr.or.ddit.mvc.multipart.MultipartFile;
import kr.or.ddit.prod.dao.OthersDAO;
import kr.or.ddit.prod.dao.OthersDAOImpl;
import kr.or.ddit.prod.dao.ProdDAO;
import kr.or.ddit.prod.dao.ProdDAOImpl;
import kr.or.ddit.prod.service.ProdService;
import kr.or.ddit.prod.service.ProdServiceImpl;
import kr.or.ddit.validate.InsertGroup;
import kr.or.ddit.validate.UpdateGroup;
import kr.or.ddit.validate.ValidationUtils;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.ProdVO;

//   /prod/prodUpdate.do
//prodInsertController랑 똑같음 

@Controller
public class ProdUpdateController {
	
	
	private ProdService service = new ProdServiceImpl();
	private OthersDAO othersDAO = new OthersDAOImpl();
//	private ProdDAO prodDAO = new ProdDAOImpl();
	
	private void addAttribute(HttpServletRequest req) {
		req.setAttribute("lprodList", othersDAO.selectLprodList());
		req.setAttribute("buyerList", othersDAO.selectBuyerList(null)); //"전체" 거래처 조회 
	}

	
	//처음 update화면이 뜰때 실행되는 구문 
	@RequestMapping("/prod/prodUpdate.do")
	public String updateForm(
			@RequestParam("what") String prodId
			, HttpServletRequest req
			
	) {
		
		addAttribute(req);
		ProdVO prod = service.retrieveProd(prodId);
		req.setAttribute("prod", prod);
		return "prod/prodForm"; 
	}
	
	
//  앞단에서 수정버튼 클릭 후 실행되는 구문  
	@RequestMapping(value="/prod/prodUpdate.do", method=RequestMethod.POST)
	public String updateProd(
			
		@ModelAttribute("prod") ProdVO prod //prodvo내용 전부 담아올수있는 거 세팅
		,HttpServletRequest req
		,@RequestPart(value="prodImg", required=false) MultipartFile prodImage
			
	) throws IOException {
			
		
		
		prod.setProdImage(prodImage); //vo에서 이미 이미지 있나ㅂ없나 보고 마임타임까지 확인한 후 ok면 이미지가 올라왔따는 거임	
//		1. 저장
		String saveFolderURL = "/resources/prodImages"; 
		ServletContext application = req.getServletContext();
		String saveFolderPath = application.getRealPath(saveFolderURL);
		File saveFolder = new File(saveFolderPath);
		if(!saveFolder.exists()) { //얘가 실제로 있나 없나 확인
			saveFolder.mkdirs();
		}
		prod.saveTo(saveFolder);
		
		
		String viewName = null;

		Map<String, List<String>> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors);
		boolean valid =  ValidationUtils.validate(prod, errors, UpdateGroup.class);
		if(valid) {
			ServiceResult result =  service.modifyProd(prod);
			if(ServiceResult.OK == result) {
				viewName = "redirect:/prod/prodView.do?what=" + prod.getProdId();
			}else {
				req.setAttribute("message", "서버오류 조금있다가 다시" );
				viewName = "prod/prodForm";
			}
		}else { //검증통과못했을 경우
			viewName = "prod/prodForm";
		}
		return viewName;
		
		
	}
}
	
	
	
	
/*	
  
  	private ProdService service = new ProdServiceImpl();
	private OthersDAO othersDAO = new OthersDAOImpl();
	private ProdDAO prodDAO = new ProdDAOImpl();
	
 
  	private void addAttribute(HttpServletRequest req) {
		//
		// <c:param name="what" value="${prod.prodId }" />
		req.setAttribute("prod", prodDAO.selectProd(req.getParameter("what")));
		
		req.setAttribute("lprodList", othersDAO.selectLprodList()); //othersDAO에서 selectLprodList에 있는 내용물 들고와서" lprodList"라는 이름으로 세팅한 후에 앞단으로 넘겨주기  
		req.setAttribute("buyerList",  othersDAO.selectBuyerList(null)); 
	}

  //처음 update화면이 뜰때 실행되는 구문 
	@RequestMapping("/prod/prodUpdate.do")
	public String process(
			HttpServletRequest req
	) {
		
		addAttribute(req); //req : 앞단에서 링크(제품명(prodId 제품명링크))를 클릭했을 때 여기로 응답이 넘어와서 실행  
	
		//이렇게 하면 더러우니까 위에 method 따로 빼서 추가 
		//String prodId = req.getParameter("what");
		//ProdVO prodVO = dao.selectProd(prodId);
		
	
		return "prod/prodForm"; 
	}
	
	*/

/*	//  앞단에서 수정버튼 클릭 후 실행되는 구문  
	@RequestMapping(value="/prod/prodUpdate.do", method=RequestMethod.POST)
	public String updateProcess(
		@ModelAttribute("prod") ProdVO prod
		,@RequestPart("prodImg") MultipartFile prodImage
		,HttpServletRequest req
	) throws IOException {
		
		addAttribute(req);
		
				if(req instanceof  MultipartHttpServletRequest) {
		MultipartHttpServletRequest wrapperReq =  (MultipartHttpServletRequest) req;
		//prodImage -> prodImg
		MultipartFile prodImage = wrapperReq.getFile("prodImg"); //<input type="file" name="prodImg" accept="image/*" />
			if(prodImage != null && !prodImage.isEmpty()) { //prodImage있으면 실행 

			//prodImages : 클라이언트가 보낼때 사용하는거
			//prodImg : DB 저장용 이름
			//클라이언트가 prodImages로 보내면 prodImg로 바꿔서 DB에 넣기 
			
//			1. 저장
			String saveFolderURL = "/resources/prodImages"; 
			ServletContext application = req.getServletContext();
			String saveFolderPath = application.getRealPath(saveFolderURL);
			File saveFolder = new File(saveFolderPath);
			if(!saveFolder.exists()) { //얘가 실제로 있나 없나 확인
				saveFolder.mkdirs();
			}
			
//			2. METADATA 추출
			String saveFileName = UUID.randomUUID().toString();
			prodImage.transferTo(new File(saveFolder, saveFileName));

			
//			3.DB 저장 : prodImg 만들기 
			prod.setProdImg(saveFileName);
			
		}	

		
		
		//errors에 대한 map 만들기 => map의 type은 string, value는 List<String>
		Map<String, List<String>> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors); 
		boolean valid =  ValidationUtils.validate(prod, errors, InsertGroup.class);
		
		String viewName = null;
		if(valid) {
			ServiceResult result =  service.createProd(prod);
			if(ServiceResult.OK == result) {
				viewName = "redirect:/prod/prodView.do?what=" + prod.getProdId();
			}else {
				req.setAttribute("message", "서버오류 조금있다가 다시" );
				viewName = "prod/prodForm";
			}
		}else { //검증통과못했을 경우
			viewName = "prod/prodForm";
		}
		return viewName;
	
}*/
	
	
	
	
	
	
	


